﻿using DataAccessLayer;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class MockTestService
    {
        private MockTestRepository mockTestRepository;

        public MockTestService()
        {
            mockTestRepository = new MockTestRepository();
        }

        public List<MockTest> GetAllMockTests()
        {
            return mockTestRepository.GetAllMockTests();
        }

        public List<MockTest> GetAllByCondition(string testTitleOrSkillArea)
        {
            return mockTestRepository.GetAllByCondition(testTitleOrSkillArea);
        }

        public bool DeleteItem(MockTest item)
        {
            return mockTestRepository.DeleteItem(item);
        }

        public bool CheckExistingId(int itemId)
        {
            return mockTestRepository.CheckExistingId(itemId);
        }


        public bool UpdateItem(MockTest itemChange)
        {
            return mockTestRepository.UpdateItem(itemChange);
        }

        public bool AddItem(MockTest newItem)
        {
            return mockTestRepository.AddItem(newItem);
        }
    }
}
