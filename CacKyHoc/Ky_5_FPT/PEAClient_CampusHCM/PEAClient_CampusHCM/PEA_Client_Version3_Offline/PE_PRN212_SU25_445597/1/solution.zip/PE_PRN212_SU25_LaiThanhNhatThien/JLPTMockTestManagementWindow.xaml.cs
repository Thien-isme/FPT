﻿using DataAccessLayer;
using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PE_PRN212_SU25_SE182117
{
    /// <summary>
    /// Interaction logic for JLPTMockTestManagementWindow.xaml
    /// </summary>
    public partial class JLPTMockTestManagementWindow : Window
    {
        private Jlptaccount currentUser;
        private CandidateService candidateService = new CandidateService();
        private MockTestService mockTestService = new MockTestService();
        private string action;
        public JLPTMockTestManagementWindow(Jlptaccount user)
        {
            InitializeComponent();
            currentUser = user;
            LoadItems();
            LoadComboBox();
            RolePermission();
        }


        private void LoadItems()
        {
            try
            {
                dgData.ItemsSource = null;
                var inventoryItems = mockTestService.GetAllMockTests();
                if (inventoryItems != null && inventoryItems.Count > 0)
                {
                    dgData.ItemsSource = inventoryItems;
                }
                else
                {
                    MessageBox.Show("No items found.", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        private void LoadComboBox()
        {
            try
            {
                cmbFullName.ItemsSource = null;
                List<Candidate> productionCompanies = candidateService.GetAllCandidates();
                cmbFullName.ItemsSource = productionCompanies;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        private void RolePermission()
        {
            try
            {
                if (currentUser.Role == 2)
                {
                    btnDelete.IsEnabled = false;
                }

                if (currentUser.Role == 3)
                {
                    btnAdd.IsEnabled = false;
                    btnUpdate.IsEnabled = false;
                    btnDelete.IsEnabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }


        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string testTitleOrSkillArea = txtTestTitleOrSkillArea.Text.Trim();

                var result = mockTestService.GetAllByCondition(testTitleOrSkillArea);
                dgData.ItemsSource = null;
                dgData.ItemsSource = result;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

        }



        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dgData.SelectedIndex < 0)
                {
                    MessageBox.Show("Please select an item before delete", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }


                dgData.SelectedItem = dgData.Items[dgData.SelectedIndex];
                MockTest item = (MockTest)dgData.SelectedItem;
                MessageBoxResult result = MessageBox.Show($"Are you sure you want to delete the item", "Confirm Delete", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.No)
                {
                    return;
                }
                else
                {
                    if (mockTestService.DeleteItem(item) == true)
                    {
                        MessageBox.Show("Item deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        ClearInfor();
                    }
                    else
                    {
                        MessageBox.Show("Failed to delete item.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    LoadItems();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        private void dgData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                if (dgData.SelectedIndex < 0)
                {
                    return; // No item selected
                }

                LoadComboBox();
                MockTest itemSelected = (MockTest)dgData.SelectedItem;
                // Populate the text boxes with the selected item's details
                txtTestId.Text = itemSelected.TestId.ToString();
                txtTestTitle.Text = itemSelected.TestTitle;
                txtSkillArea.Text = itemSelected.SkillArea;
                dpStartTimeDate.Text = itemSelected.StartTime.ToString();
                dpEndTimeDate.Text = itemSelected.EndTime.ToString();
                txtScore.Text = itemSelected.Score.ToString();
                cmbFullName.SelectedValue = itemSelected.CandidateId;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }



        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateValue() == false)
                {
                    return;
                }

                MockTest newItem = new MockTest();
                newItem.TestId = int.Parse(txtTestId.Text.Trim());
                newItem.TestTitle = txtTestTitle.Text.Trim();
                newItem.SkillArea = txtSkillArea.Text.Trim();
                //newItem.StartTime = TimeOnly.Parse(dpStartTimeDate.SelectedDate);
                //newItem.EndTime = dpEndTimeDate.Text.Trim();
                newItem.Score = double.Parse(txtScore.Text.Trim());
                newItem.CandidateId = int.Parse(cmbFullName.SelectedValue.ToString());

                // Check existingId
                int itemId = int.Parse(txtTestId.Text.Trim());
                bool existingId = mockTestService.CheckExistingId(itemId);
                if (existingId)
                {
                    MessageBox.Show("Item ID already exists. Please enter a unique ID.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                // Add into DB
                if (mockTestService.AddItem(newItem))
                {
                    MessageBox.Show("Item added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearInfor();
                }
                else
                {
                    MessageBox.Show("Failed to add item. Please check the item ID.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                LoadItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

        }



        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (ValidateValue() == false)
                {
                    return;
                }
                MockTest newItem = new MockTest();
                newItem.TestId = int.Parse(txtTestId.Text.Trim());
                newItem.TestTitle = txtTestTitle.Text.Trim();
                //newItem.EndTime = dpEndTimeDate.Text.Trim();
                //newItem.StartTime = dpStartTimeDate.SelectedDate;
                newItem.Score = double.Parse(txtScore.Text.Trim());
                newItem.SkillArea = txtSkillArea.Text.Trim();
                newItem.CandidateId = int.Parse(cmbFullName.SelectedValue.ToString());
                // Update into DB
                if (mockTestService.UpdateItem(newItem) == true)
                {
                    MessageBox.Show("Item updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearInfor();
                }
                else
                {
                    MessageBox.Show("No new data to update. Please input new value", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                LoadItems();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
        }

        private bool ValidateValue()
        {
            try
            {
                // Check for empty fields
                if (string.IsNullOrWhiteSpace(txtTestId.Text) ||
                    string.IsNullOrWhiteSpace(txtTestTitle.Text) ||
                    string.IsNullOrWhiteSpace(txtSkillArea.Text) ||
                    //dpDate.SelectedDate == null ||
                    string.IsNullOrWhiteSpace(txtScore.Text) ||
                    cmbFullName.SelectedValue == null)
                {
                    MessageBox.Show("Please fill in all fields.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return false;
                }


                //1.Check for special characters
                //if (dpDate.SelectedDate.Value > new DateTime(2004, 1, 1))
                //{
                //    MessageBox.Show("Please select a date on or after January 1, 2004.", "Invalid Date", MessageBoxButton.OK, MessageBoxImage.Warning);
                //    return false;
                //}

                // 2. Check that each word starts with capital letter or digit (1-9)
                //string[] words = txtPerfumeName.Text.Split(' ');
                //foreach (string word in words)
                //{
                //    if (string.IsNullOrEmpty(word))
                //        continue;

                //    char firstChar = word[0];
                //    if (!(char.IsUpper(firstChar) || (char.IsDigit(firstChar) && firstChar != '0')))
                //    {
                //        MessageBox.Show("Each word of the PerfumeName must begin the capital letter or digit (1 - 9).", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                //        return false;
                //    }
                //}

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    ClearInfor();
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return;
            //}
        }

        private void ClearInfor()
        {
            //try
            //{
            //    cmbFootballTeamTitle.SelectedIndex = -1;
            //    txtPlayerNameAction.Clear();
            //    txtOriginCountry.Clear();
            //    txtAchievementsAction.Clear();
            //    dpDate.SelectedDate = null;
            //    txtAward.Clear();
            //    txtPlayerId.Clear();
            //    dgData.SelectedIndex = -1;
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            //    return;
            //}
        }

    }
}
