﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class CandidateRepository
    {
        private Su25jlptmockTestDbContext _context;

        public CandidateRepository()
        {
            _context = new Su25jlptmockTestDbContext();
        }

        public List<Candidate> GetAllCandidates()
        {
            return _context.Candidates.ToList();
        }

        
    }
}
