﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class JlptaccountRepository
    {
        private Su25jlptmockTestDbContext _context;

        public JlptaccountRepository()
        {
            _context = new Su25jlptmockTestDbContext();
        }

        public Jlptaccount Login(string email, string password)
        {
            return _context.Jlptaccounts
                .FirstOrDefault(u => u.Email.Equals(email) && u.Password.Equals(password));
        }

    }
}
