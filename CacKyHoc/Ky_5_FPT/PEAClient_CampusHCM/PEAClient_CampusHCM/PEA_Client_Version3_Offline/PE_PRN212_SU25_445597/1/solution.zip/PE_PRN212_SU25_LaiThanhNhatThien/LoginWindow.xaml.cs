﻿using Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PE_PRN212_SU25_SE182117
{
    /// <summary>
    /// Interaction logic for LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        JlptaccountService jlptaccountService = new JlptaccountService();
        public LoginWindow()
        {
            InitializeComponent();
        }


        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Password.Trim();

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Invalid Email or Password!", "Login Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            var user = jlptaccountService.Login(email, password);
            if (user == null)
            {
                MessageBox.Show("Invalid Email or Password!", "Login Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (user != null && user.Role != 4)
            {
                // Login successful, open the main window
                JLPTMockTestManagementWindow preOrderManagementWindow = new JLPTMockTestManagementWindow(user);
                this.Close(); // Close the login window
                preOrderManagementWindow.Show();
            }
            else
            {
                // Login failed, show error message
                MessageBox.Show("You have no permission to access this function!", "Login Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
