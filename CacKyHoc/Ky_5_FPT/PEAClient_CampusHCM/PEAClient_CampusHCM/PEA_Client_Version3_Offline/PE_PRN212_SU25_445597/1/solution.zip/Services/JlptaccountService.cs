﻿using DataAccessLayer;
using Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services
{
    public class JlptaccountService
    {
        private JlptaccountRepository jlptaccountRepository;

        public JlptaccountService()
        {
            jlptaccountRepository = new JlptaccountRepository();
        }

        public Jlptaccount Login(string email, string password)
        {
            return jlptaccountRepository.Login(email, password);
        }
    }
}
