﻿using DataAccessLayer;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories
{
    public class MockTestRepository
    {
        private Su25jlptmockTestDbContext _context;

        public MockTestRepository()
        {
            _context = new Su25jlptmockTestDbContext();
        }

        public List<MockTest> GetAllMockTests()
        {
            return _context.MockTests
                .Include(m => m.Candidate)
                .ToList();
        }

        public List<MockTest> GetAllByCondition(string testTitleOrSkillArea)
        {
            List<MockTest> result = GetAllMockTests();
            if (!string.IsNullOrEmpty(testTitleOrSkillArea))
            {
                result = result.Where(rp => rp.TestTitle.ToLower().Contains(testTitleOrSkillArea.ToLower()) || rp.SkillArea.ToLower().Contains(testTitleOrSkillArea.ToLower()))
                         .ToList();
            }


            return result;
        }

        public bool DeleteItem(MockTest item)
        {
            var extingsMockTest = _context.MockTests
                .FirstOrDefault(p => p.TestId == item.TestId);
            if (extingsMockTest == null)
            {
                return false; // Item not found
            }

            _context.MockTests.Remove(extingsMockTest);
            return _context.SaveChanges() > 0;
        }

        public bool CheckExistingId(int itemId)
        {
            return _context.MockTests
                .Any(p => p.TestId == itemId);
        }


        public bool UpdateItem(MockTest itemChange)
        {
            int itemId = itemChange.TestId;
            var existingItem = _context.MockTests
                .FirstOrDefault(p => p.TestId == itemChange.TestId);
            if (existingItem == null)
            {
                return false; // Item not found
            }
            // Update the existing item with the new values
            existingItem.TestTitle = itemChange.TestTitle;
            existingItem.StartTime = itemChange.StartTime;
            existingItem.EndTime = itemChange.EndTime;
            existingItem.Score = itemChange.Score;
            existingItem.SkillArea = itemChange.SkillArea;
            existingItem.CandidateId = itemChange.CandidateId;
            //existingItem.ProductId = itemChange.ProductId;
            //existingItem.Status = itemChange.Status;
            //existingItem.UpdatedAt = DateOnly.FromDateTime(DateTime.Now);
            // Update the item in the context
            return _context.SaveChanges() > 0;
        }

        public bool AddItem(MockTest newItem)
        {
            _context.MockTests.Add(newItem);
            return _context.SaveChanges() > 0;
        }




    }
}
