/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import pe.model.HouseDAO;
import pe.model.HouseDTO;
import pe.model.UserDAO;
import pe.model.UserDTO;

/**
 *
 * @author hd
 */
public class MainController extends HttpServlet {

    private static final String LOGIN_PAGE = "login.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = LOGIN_PAGE;
        try {
            String action = request.getParameter("action");
            if (action == null) {
                url = LOGIN_PAGE;
            }
//            your code here
            if (action.equals("login")) {
                url = login(request, response);
            } else if (action.equals("logout")) {
                url = logout(request, response);
            } else if (action.equals("search")) {
                url = search(request, response);
            } else if (action.equals("delete")) {
                url = delete(request, response);
            }

        } catch (Exception e) {
            log("Error at MainController: " + e.toString());
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String login(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        String url = "";

        String userID = request.getParameter("userID");
        String password = request.getParameter("password");

        UserDAO dao = new UserDAO();
        UserDTO user = dao.checkLogin(userID, password);

        if (user != null) {
            HttpSession session = request.getSession(true);
            session.setAttribute("user", user);
            url = "houseList.jsp";
        } else {
            request.setAttribute("error", "Incorrect UserID or Password");
            url = "login.jsp";
        }

        return url;
    }

    private String logout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession(false);
        UserDTO userDTO = (UserDTO) session.getAttribute("user");
        if (userDTO == null) {
            return "login.jsp";
        }

        if (session != null) {
            session.invalidate();
        }

        return "login.jsp";

    }

    private String search(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        HttpSession session = request.getSession(false);
        UserDTO userDTO = (UserDTO) session.getAttribute("user");
        if (userDTO == null) {
            return "login.jsp";
        }

        String keyword = request.getParameter("keyword");

        HouseDAO dao = new HouseDAO();
        List<HouseDTO> list = new ArrayList<HouseDTO>();
        list = dao.selectByName(keyword);

        request.setAttribute("keyword", keyword);
        request.setAttribute("list", list);

        return "houseList.jsp";
    }

    private String delete(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        HttpSession session = request.getSession(false);
        UserDTO userDTO = (UserDTO) session.getAttribute("user");
        if (userDTO == null) {
            return "login.jsp";
        }

        String id = request.getParameter("id");

        HouseDAO dao = new HouseDAO();
        dao.delete(id);

        String keyword = request.getParameter("keyword");

        List<HouseDTO> list = new ArrayList<HouseDTO>();
        list = dao.selectByName(keyword);

        request.setAttribute("keyword", keyword);
        request.setAttribute("list", list);

        return "houseList.jsp";
    }

}
