/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import pe.utils.DBUtils;

/**
 *
 * @author Admin
 */
public class HouseDAO {

    public List<HouseDTO> selectByName(String keyword) throws SQLException {
        List<HouseDTO> list = new ArrayList<HouseDTO>();

        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                String sql = " select * from tblHouse \n"
                        + " where name like ? ";
                ptm = conn.prepareStatement(sql);

                ptm.setString(1, "%" + keyword + "%");

                rs = ptm.executeQuery();

                while (rs.next()) {
                    
                    String id = rs.getString("id");
                    String name = rs.getString("name");
                    String description = rs.getString("description");
                    float price = rs.getFloat("price");
                    float size = rs.getFloat("size");
                    boolean status = rs.getBoolean("status");

                    HouseDTO house = new HouseDTO(id, name, description, price, size, status);
                    list.add(house);
                }
            }
        } catch (Exception e) {
            e.getStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return list;
    }

    public int delete(String id) throws SQLException {
        Connection conn = null;
        PreparedStatement ptm = null;
        int result = 0;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                String sql = " update tblHouse\n"
                        + " set status = '0'\n"
                        + " where id = ? ";
                ptm = conn.prepareStatement(sql);

                ptm.setString(1, id);

                result = ptm.executeUpdate();

            }
        } catch (Exception e) {
            e.getStackTrace();
        } finally {

            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return result;
    }

}
