/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pe.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import pe.utils.DBUtils;

/**
 *
 * @author Admin
 */
public class UserDAO {

    public UserDTO checkLogin(String userID, String password) throws SQLException {
        UserDTO userLogin = null;
        Connection conn = null;
        PreparedStatement ptm = null;
        ResultSet rs = null;
        try {
            conn = DBUtils.getConnection();
            if (conn != null) {
                String sql = " select * from tblUser \n"
                        + " where userID = ?  and password = ? ";
                ptm = conn.prepareStatement(sql);

                ptm.setString(1, userID);
                ptm.setString(2, password);

                rs = ptm.executeQuery();

                if (rs.next()) {

                    String name = rs.getString("name");

                    userLogin = new UserDTO(userID, name, password);
                }

            }
        } catch (Exception e) {
            e.getStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ptm != null) {
                ptm.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
        return userLogin;

    }
}
