select *
from Events e
where e.StartTime > 2024-01-01