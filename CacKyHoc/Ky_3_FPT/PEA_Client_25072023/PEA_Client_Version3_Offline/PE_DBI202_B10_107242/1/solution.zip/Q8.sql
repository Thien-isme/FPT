insert into Staffs(name, Phone)
values ('John Doe', '555-987-6543'), 
		('Jane Smith', '555-654-3210'),
		('Alice Brown', '555-123-7890')
