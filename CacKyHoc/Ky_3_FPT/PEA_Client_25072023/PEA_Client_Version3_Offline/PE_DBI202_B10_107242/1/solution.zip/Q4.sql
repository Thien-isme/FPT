select e.eventID, count(s.staffID) as NumberStaff
from Events e join workFor w on e.eventID = w.eventID
join Staffs s on s.staffID = w.staffID
group by e.eventID
having count(s.staffID) > =2