select e.eventID, e.name, e.StartTime, e.EndTime, l.locationID
from Staffs s join workFor w on s.staffID = w.staffID
join Events e on e.eventID = w.eventID
join Locations l on l.locationID = e.locationID
group by e.eventID, e.name, e.StartTime, e.EndTime, l.locationID
having count(s.staffID) > 1