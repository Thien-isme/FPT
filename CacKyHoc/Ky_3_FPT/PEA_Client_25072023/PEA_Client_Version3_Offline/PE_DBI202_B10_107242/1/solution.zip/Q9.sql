update Staffs
set Phone = '999'+SUBSTRING(Phone, 4, 15)
where Phone like '555%'


















