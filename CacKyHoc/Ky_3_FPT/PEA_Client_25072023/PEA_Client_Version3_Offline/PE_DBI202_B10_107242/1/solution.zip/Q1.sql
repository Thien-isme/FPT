create table Departments(
DepID varchar(20) primary key,
name nvarchar(200),
office nvarchar(100),
)

create table Employees(
EmpCode varchar(20) primary key,
Name nvarchar(50),
BirthDate  date,
DepID varchar(20) foreign key references Departments(DepID)
)

create table Dependants(
Number int primary key,
EmpCode varchar(20) foreign key references Employees(EmpCode),
Name nvarchar(50),
BirthDate date,
Role nvarchar(30),
)


