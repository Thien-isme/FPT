select e.name as EventName, l.Name as LocationName, s.name as StaffName
from Staffs s join workFor w on s.staffID = w.staffID
join Events e on e.eventID = w.eventID
join Locations l on l.locationID = e.locationID
