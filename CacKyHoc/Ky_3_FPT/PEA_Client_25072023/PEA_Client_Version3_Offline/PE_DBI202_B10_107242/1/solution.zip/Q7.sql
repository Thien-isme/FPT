select l.Name
from Events e join Locations l on e.locationID = l.locationID
group by l.Name
having count(e.eventID) = (
						select top 1 count(e.eventID) as sum
						from Events e join Locations l on e.locationID = l.locationID
						group by l.Name
						order by sum desc
						)
	




