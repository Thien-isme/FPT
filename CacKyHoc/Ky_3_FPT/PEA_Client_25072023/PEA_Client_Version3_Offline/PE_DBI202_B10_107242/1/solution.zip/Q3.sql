select l.locationID, count(e.eventID) as TotalEvents
from Events e join Locations l on e.locationID = l.locationID
group by l.locationID